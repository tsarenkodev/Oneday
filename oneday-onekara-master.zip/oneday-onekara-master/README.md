# oneday-onekara

Social network bot to post a Live link with pictures